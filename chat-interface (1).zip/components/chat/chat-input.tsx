"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { SendIcon } from "lucide-react"
import type { KeyboardEvent } from "react"

interface ChatInputProps {
  input: string
  setInput: (value: string) => void
  handleSendMessage: () => void
}

export function ChatInput({ input, setInput, handleSendMessage }: ChatInputProps) {
  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="flex items-center gap-2 bg-background/80 backdrop-blur-sm p-4 border-t">
      <Input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Type a message..."
        className="flex-1 py-6 bg-background"
      />
      <Button onClick={handleSendMessage} size="icon" disabled={!input.trim()} className="h-12 w-12 rounded-full">
        <SendIcon className="h-5 w-5" />
      </Button>
    </div>
  )
}
