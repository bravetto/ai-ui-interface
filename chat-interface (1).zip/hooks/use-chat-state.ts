"use client"

import { useState } from "react"
import type { Message } from "@/types/chat"

export function useChatState() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)

  const addMessage = (content: string, role: "user" | "assistant") => {
    const newMessage: Message = {
      id: Date.now().toString(),
      content,
      role,
      createdAt: new Date(),
    }
    setMessages((prev) => [...prev, newMessage])
  }

  const handleSendMessage = () => {
    if (!input.trim()) return

    // Add user message
    addMessage(input, "user")
    setInput("")

    // Simulate AI typing
    setIsTyping(true)

    // Simulate AI response after a delay
    setTimeout(() => {
      addMessage("This is a simulated response from the AI assistant.", "assistant")
      setIsTyping(false)
    }, 1500)
  }

  return {
    messages,
    input,
    setInput,
    isTyping,
    handleSendMessage,
  }
}
