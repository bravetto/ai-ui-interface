"use client"

import { Chat } from "@/components/chat/chat"
import { ThemeProvider } from "@/components/theme-provider"
import { Button } from "@/components/ui/button"
import { MoonIcon, SunIcon } from "lucide-react"
import { useTheme } from "next-themes"

export default function ChatPage() {
  const { theme, setTheme } = useTheme()

  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
      <div className="flex flex-col h-screen bg-background">
        <header className="border-b p-4 flex justify-between items-center">
          <h1 className="text-xl font-bold">Chat Interface</h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            aria-label="Toggle theme"
          >
            <SunIcon className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <MoonIcon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
          </Button>
        </header>
        <main className="flex-1 overflow-hidden">
          <div className="container mx-auto h-full max-w-4xl">
            <Chat />
          </div>
        </main>
      </div>
    </ThemeProvider>
  )
}
